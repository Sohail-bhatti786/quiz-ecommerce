import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.page.html',
  styleUrls: ['./checkout.page.scss'],
})
export class CheckoutPage implements OnInit {
newOrder:any;
paymentMethods:any[];
paymentMethod:any;
billing_shipping_same:boolean;

  constructor(public navCtrl:NavController) {
    this.newOrder={};
    this.newOrder.billing_address={};
    this.newOrder.shipping_address={};
    this.billing_shipping_same=false;

    this.paymentMethod=[
      {method_id:"bacs",method_title:"Direct Bank Transfer"},
      {method_id:"cheque",method_title:"cheque payment"},
      {method_id:"card",method_title:"cash on Delivery"},
      {method_id:"paypal",method_title:"paypal"}
    ]
   }

   setBillingToShiping(){
    this.billing_shipping_same = !this.billing_shipping_same;
 
    if(this.billing_shipping_same)
    {
      this.newOrder.shipping_address = this.newOrder.billing_address;
    }
  }

  ionViewDidLoad(){
    console.log('ionViewDidLoad Checkout');
  }
  ngOnInit() {
  }


 
}
