import { Component } from '@angular/core';
import { NavController,AlertController } from '@ionic/angular';
import { TodoService } from '../ionic g service services/todo.service';
@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  users=[];
  selectedProduct:string;
  public menus=[];
  
  constructor(public ms:TodoService ,  public navCtrl: NavController,private ac:AlertController) {
    
  }
  async openMenuAlert(){
     let addMenuAlert= await this.ac.create({
       header:'Add Menu',
       message:'Enter your Menu',
       inputs:[{
        type:'text',
        name:'addMenuInput'
     }],
     buttons:[
       {text:'cancle'},
       {
         text:'Add Menu',
          handler:() =>{
           console.log('addmenu')
           
          }
      },
       
     ]
     });
     addMenuAlert.present();
   }

   isValid:boolean=false;

   oncreate(){
     this.isValid=true;
   }
   

   getProductval(val){
     console.log(val.target.value)
     this.selectedProduct=val.target.value;
   }

   onCreateUser(uname){
     this.users.push({
       name:uname.value
     });
   }

   onremove(){
     this.users.splice(this.users.length -1)
   }

   onRemoveUser(item){
     this.users.splice(item, 1)
   }
}
