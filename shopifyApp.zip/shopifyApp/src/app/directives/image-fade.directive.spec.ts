import { ImageFadeDirective } from './image-fade.directive';

describe('ImageFadeDirective', () => {
  it('should create an instance', () => {
    const directive = new ImageFadeDirective();
    expect(directive).toBeTruthy();
  });
});
