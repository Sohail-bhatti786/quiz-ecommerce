import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TodoService {
 private menus = [];
  constructor(public http:HttpClient) {
    console.log('hello services');
   }
   getMenus(){
     return this.menus;
   }
   addMenu(menu){
     this.menus.push(menu);
   }
}
